//Almog Fadida ID 315544437. Moran Arzi ID 200244945
package assig3_1;

public class Judge implements Runnable{
	
	//private Gamer p1;
	//private Gamer p2;
	GamePlay g1;
	
//	Judge(Gamer p1, Gamer p2){
//		this.p1 = p1;
//		this.p2 = p2;
//	}
	
	Judge(GamePlay g1){
	this.g1 = g1;
}
		
	public void run() { //add here something
		

		while (!Thread.currentThread().isInterrupted()) { 
			
			try {
				g1.makeCoinAvail(false); //fix here
				Thread.sleep(1000);
				g1.makeCoinAvail(true); //fix here
				Thread.sleep(500);
			}
			catch(InterruptedException e) {
				
				e.printStackTrace();
				break;//for interrupt
			}
		
		
	} //end while
	
}//end run function

}//end Judge class