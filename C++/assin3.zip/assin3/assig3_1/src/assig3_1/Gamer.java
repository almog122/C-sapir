//Almog Fadida ID 315544437. Moran Arzi ID 200244945
package assig3_1;

public class Gamer implements Runnable{

	
	private int goodFlipsCounter;
	private GamePlay g;
	
	Gamer(int goodFlipsCounter ,GamePlay g){
		
		this.goodFlipsCounter = goodFlipsCounter;
		
		this.g = g;
		
	}
	
	public void play() {
		
		while (!Thread.currentThread().isInterrupted() && g.getNumOfRounds() < 10) {
			
			try  {//or somehow inside try?
				 
				if(g.flipCoin() == 1);
				 	goodFlipsCounter++;
				
				Thread.sleep(1000);//maybe fix this. 
				
			}
			catch(InterruptedException e) {
				
				e.printStackTrace();
				break;//for interrupt
			}
			
		}//end while
		
		}//end play function
	
	public int getScore() {
		return goodFlipsCounter;
	}
	
	
	public void run() { //add here something
		play();
		
		
		
	} //end run function
	
	
	
} //end Gamer class
