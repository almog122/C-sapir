//Almog Fadida ID 315544437. Moran Arzi ID 200244945

package assig3_1;


public class GamePlay {

	
	private boolean coin_available_; //The shared source
	private int rounds_counter_;
	private int rand_num;
	
	GamePlay(boolean coin_available, int rounds_counter_, int rand_num ){
		this.coin_available_ = coin_available;
		this.rounds_counter_ = rounds_counter_;
		this.rand_num = rand_num;
	}
	
	public synchronized void makeCoinAvail (boolean val) {
		
		if (val == true) { //or while
			coin_available_ = true;
			notifyAll();
		}
		
		else {
			coin_available_ = false;	
		}
		
		//coin_available_ = val; ? see inst
		
	} //end makeCoinAvail function
	
	
	
	public synchronized int flipCoin(){
		
		
		while (!coin_available_) {
			
			try {
				wait();//maybe fix this. maybe without this.
			}
			catch(InterruptedException e) {
				
				e.printStackTrace();
			}	
			
			System.out.println (Thread.currentThread().getName() + " is waiting for coin");
		}
		
		if (coin_available_) {
	
			System.out.println (Thread.currentThread().getName() + " is flipping coin");
			makeCoinAvail(false);
			rounds_counter_++;
			rand_num = (int)Math.random() * 2; //random number from 0 to 2 (not included) - so 0 or 1.
			makeCoinAvail(true); //and notify all is inside the function
		
		}
		
		if (rand_num == 1) { //or while?
			
			return 1; //means true
		}else {
			
			return 0; //means false, failure
		}
		
		
	} //end flipCoin function
	
	
	public int getNumOfRounds(){
		
		return rounds_counter_;
	}//end getNumOfRounds functions
	
	
	
} //end GamePlay class
