//Almog Fadida. ID 315544437. Moran Arzi. ID 200244945
package assign2_1;

public class MatrixCounter implements Runnable {
	
	
	private int row;
	private Matrix matrix;
	
	
	//constractor
	MatrixCounter(int row, Matrix matrix) { 
		
		this.row = row;
		this.matrix = matrix;
	}
	
	
	
	public void run() {
		
		int i;
		int rowSum = 0;
	
		for(i = 0; i < matrix.getOurCol(); i++) {
			rowSum += matrix.getmat()[row][i]; 
		}
		
		matrix.addMatrixSum(rowSum);
	
	} //end of run function

}
